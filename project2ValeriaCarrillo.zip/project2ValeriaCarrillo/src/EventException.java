/*custom exception for Host class it is an unchecked exception*/

public class EventException extends RuntimeException{
    public EventException(String message){
        super(message);
    }

}
